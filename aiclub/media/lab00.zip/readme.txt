both username and pass help you to brute force but how ?

we have a list of password 13 
and usernames 11

the key is having "combonation for the each user have all possible passwords provided !"

try using netest loop ? 
you will have a all combonation togther will be 11*13 = 143 possible user:password 
for each user will have = 13 probralty that and on of them is correct ( for real secinaro maybe not )

الخلاصة ، هذي تجربه على مستند من المستخدمين والباسوردات 
في الواقع يكون عندك هدف واحد وممكن تحط مستند يحتوي على سبيل مثال مليون باسورد
وتبدا تجرب لين ينجح 

لكن العمليه ممكن تاخذ الى الابد اذا بنستخدم سيلينوم 
وش الحل وكيف ؟ 

wait for Parallel Progamming - Request next semester :D
